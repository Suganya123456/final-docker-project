export class Users{
    id: number;
    firstName: string;
    lastName: string;
    accountNo: number;
    ifscCode: string;
    phoneNo: number;
    email: string;
    
    constructor(id: number, firstName: string, lastName: string, accountNo: number, ifscCode: string, phoneNo: number, email: string){
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.accountNo = accountNo;
    this.ifscCode = ifscCode;
    this.phoneNo = phoneNo;
    this.email = email;
    }
    }