export class UserDetails {
    username : String = "";
    password : String = "";
    mobileNo: String = "";
    email: String = "";
    accountNumber : String = "";
    ifscCode : String = "";

   // firstName: String = "";
   // lastName: String = "";
   // accountNo: String = "";
   
  //  phoneNo: String = "";
   
    
}